﻿using System;
using RimWorld;
using Verse;

namespace BlackWidows
{
    [DefOf]
    public static class WidowDefOf
    {
        public static JobDef WidowMilkyLover;

        public static JobDef WidowMilkySelf;
    }
}
