﻿using System;
using System.Collections.Generic;
using Verse;

namespace BlackWidows
{
    public class PawnTerrainHandler : DefModExtension
    {
        public List<string> tags;
    }
}
