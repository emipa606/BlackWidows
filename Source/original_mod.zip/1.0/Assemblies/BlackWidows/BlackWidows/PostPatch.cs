﻿using System;
using Verse;

namespace BlackWidows
{
    [StaticConstructorOnStartup]
    public static class PostPatch
    {
    }
}
